create function gao() returns TABLE(id integer, client json, order_short_name character varying, order_info character varying, order_cost integer, order_create_date timestamp without time zone, order_deadline timestamp without time zone, order_type integer, order_status integer)
LANGUAGE SQL
AS $$
Select orders.id, (select row_to_json(t) from (select clients.id, clients.name from clients where clients.id = orders.client) t) as Rr,
   orders.order_short_name, orders.order_info, orders.order_cost, orders.order_create_date, orders.order_deadline, orders.order_type, orders.order_status 
   From orders 
   where orders.user_id = 2;
$$;
