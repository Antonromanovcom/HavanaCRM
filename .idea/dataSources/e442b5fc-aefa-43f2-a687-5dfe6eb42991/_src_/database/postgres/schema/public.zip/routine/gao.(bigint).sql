create function gao(userid bigint DEFAULT 2) returns TABLE(id integer, client json, order_short_name character varying, order_info character varying, order_cost integer, order_create_date timestamp without time zone, order_deadline timestamp without time zone, order_type integer, sub_type integer, plan integer, order_status json)
LANGUAGE SQL
AS $$
Select orders.id, (select row_to_json(t) from (select clients.id, clients.name from clients where clients.id = orders.client) t) as Rr,
   orders.order_short_name, orders.order_info, orders.order_cost, orders.order_create_date, orders.order_deadline, 
   orders.order_type, orders.order_sub_type, orders.order_plan, 
   (select row_to_json(s) from (select order_status.id, order_status.status from order_status where order_status.id = orders.order_status) s) as Status 
   From orders 
   where orders.user_id = $1;
$$;
