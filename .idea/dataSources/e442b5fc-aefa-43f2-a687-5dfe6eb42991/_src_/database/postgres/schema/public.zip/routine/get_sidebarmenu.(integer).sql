create function get_sidebarmenu(v1 integer) returns SETOF sidebarmenuitems
LANGUAGE SQL
AS $$
Select * 
   From sidebarmenuitems 
   where sidebarmenuitems.user = v1;
$$;
