create function onlylogincheck(login character varying) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
tmp integer;
BEGIN
SELECT count(*) INTO tmp FROM users WHERE users.login = $1;

IF tmp>0 THEN
      RETURN TRUE;
   ELSE
      RETURN FALSE;
   END IF;
END;
$$;
