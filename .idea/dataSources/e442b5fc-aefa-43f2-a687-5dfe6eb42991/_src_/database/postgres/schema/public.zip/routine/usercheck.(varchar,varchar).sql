create function usercheck(login character varying, pwd character varying) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
tmp integer;
BEGIN
SELECT count(*) INTO tmp FROM users WHERE users.login = $1 AND users.pwd=$2;

IF tmp>0 THEN
      RETURN TRUE;
   ELSE
      RETURN FALSE;
   END IF;
END;
$$;
