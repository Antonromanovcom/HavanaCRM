create function userid(login character varying, pwd character varying) returns integer
LANGUAGE plpgsql
AS $$
DECLARE
tmp integer;
BEGIN
SELECT users.id INTO tmp FROM users WHERE users.login = $1 AND users.pwd=$2;
      RETURN tmp;
END;
$$;
