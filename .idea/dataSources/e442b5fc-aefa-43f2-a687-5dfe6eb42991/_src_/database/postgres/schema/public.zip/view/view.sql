CREATE VIEW view AS SELECT ordertypes.type AS ordertypescount,
    count(ordertypes.type) AS test
   FROM (ordertypes
     LEFT JOIN orders ON ((ordertypes.id = orders.order_type)))
  WHERE (orders.user_id = 2)
  GROUP BY ordertypes.type;
