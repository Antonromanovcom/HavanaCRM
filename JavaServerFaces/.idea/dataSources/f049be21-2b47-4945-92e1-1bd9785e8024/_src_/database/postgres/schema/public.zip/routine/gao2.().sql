create function gao2() returns json
LANGUAGE SQL
AS $$
select row_to_json(dd) from (Select orders.id, (select row_to_json(t) from (select clients.id, clients.name from clients where clients.id = orders.client) t) as Rr,
   orders.order_short_name, orders.order_info, orders.order_cost, orders.order_create_date, orders.order_deadline, orders.order_type, orders.order_status 
   From orders 
   where orders.user_id = 2) as dd;
$$;
