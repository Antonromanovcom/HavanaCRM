create function get_options_for_plan(plan_id integer DEFAULT 2) returns TABLE(json json)
LANGUAGE SQL
AS $$
SELECT json_agg(r.*) as tags FROM (Select p.id, p.optionname From options p where p.plan_id=$1) AS r;
$$;
